## Desafio 1

### Concideraciones

* El texto a cifrar se encuentra en ```string.txt``` y quedara cifrado en ```string_cifrado.txt```.
* Se incorporo una funcion llamada ```cifrarLetra``` que busca la letra y la cifra retornandoselo al ```cifrarTexto``` para ir sumandoselo al string nuevo.
* Se incorporo una funcion llamada ```cifrarArchivo``` la cual guarda el nuevo string en ```string_cifrado.txt```.
* Se utilizo el modulo ```fs``` para leer y escribir archivos.

