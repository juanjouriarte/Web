## Desafio 1

### Concideraciones

* Se importaron las funciones de ```planificacion.js``` a ```index.js```.
* Se incorporo una funcion llamada ```recibirDestino``` que checkea si existe el destino correspondiente en el arreglo de objetos ```restricciones.json```.
* ```restricciones.json``` es un arreglo de objetos de la forma ```codigo: string, destino: string, restriccion: int```.
* Si se desea cambiar el codigo de destino este debe ser cambiado en los argumentos funcion ```recibirDestino```.
* Se utilizo el modulo ```fs``` para leer y escribir archivos.

