# tarea4

## Dependencias Agregadas
Se agrego la dependencia axios para realizar las peticiones a la API

Con el comando
```
yarn add axios
```

## Uso de ChatGPT
Se utilizo chatGPT para familiarizarse con el entorno de vue, adquirir conocimiento y sobretodo para inicializar el proyecto. Todo el frontend fue realizado sin el uso de esta herramienta. Al igual que el llamado a la api.


## Project setup
```
yarn install
```

### Compiles and hot-reloads for development
```
yarn serve
```

### Compiles and minifies for production
```
yarn build
```

### Lints and fixes files
```
yarn lint
```