**A conciderar**
- Se utilizo chatgpt solo para ayudas de respuestas, no para generar respuestas completas. Fue utilizado solamente en el FrontEnd.
- Para inicializar correctamente el servidor se debe correr ```yarn dev``` desde dentro de la carpeta ```Backend```, dado que se creo un script en package.json para correr nodemon.
- Para inicializar correctamente el FrontEnd se debe correr ```yarn dev``` desde dentro de la carpeta ```FrontEnd```.
- Se debe correr yarn install en ambas carpetas para instalar las dependencias. Dado que la carpeta node_modules no se subio al zip.